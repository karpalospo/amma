import React from 'react';
import { Text, View, TextInput} from 'react-native';
import { styles } from '../global/styles'

const Input = ({label="", customStyle ={}, value, onChange = () => {}, placeholder="", type="default"}) => {

    return (
        <View style={[{marginTop: 30}, customStyle]}>
            <Text style={styles.labelInputs}>{label}</Text>
            <View style={styles.inputs}>
                <TextInput
                    placeholder={placeholder}
                    keyboardType={type}
                    style={styles.textInputs}
                    onChangeText={text => onChange(text)}
                    value={value}
                />
            </View>
        </View>
    )

}

export default Input

