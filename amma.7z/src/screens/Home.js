import React, { useState, useEffect, useRef, useContext } from 'react'
import { View, SafeAreaView, Text, StatusBar, Image, ScrollView, StyleSheet } from 'react-native'
import { styles, COLORS } from '../global/styles'
import { TareasCard } from '../components'
import moment from 'moment/min/moment-with-locales';
import { TouchableOpacity } from 'react-native-gesture-handler';

const logo = require("../../assets/logo.png")
const Menuicon1 = require("../../assets/1.png")
const Menuicon2 = require("../../assets/2.png")
const Menuicon3 = require("../../assets/3.png")
const Menuicon4 = require("../../assets/4.png")
const agendar = require("../../assets/agendar.png")
const icon1 = require("../../assets/icon1.png")
const icon2 = require("../../assets/icon2.png")
const limpieza1 = require("../../assets/limpieza1.png")
const articulo1 = require("../../assets/articulo1.png")

const Home = (props) => {

    return (
        <SafeAreaView style={styles.main}>
            <StatusBar backgroundColor={COLORS.backgroundColor} barStyle="dark-content" />
            
            <View style={[styles.row, {position: "absolute", width: 80, height: 60, backgroundColor:"#C7F0F9", borderTopLeftRadius: 15, borderTopRightRadius: 15, left:0, bottom:0, width:"100%", zIndex: 10, paddingHorizontal: 30}]}>
                <Image source={Menuicon1} style={{height: 25, width: 25}} tintColor="#7EA8CA" resizeMode="contain" />
                <Image source={Menuicon2} style={{height: 25, width: 25}} tintColor="#7EA8CA" resizeMode="contain" />
                <View style={{width: 30}} />
                
                <View style={_styles.button}>
                    <TouchableOpacity onPress={() => props.navigation.navigate("Agendar")} style={{padding:20}} >
                        <Image source={agendar} style={{height: 30, width: 30}} tintColor="#ffffff" resizeMode="contain" />
                    </TouchableOpacity>
                </View>

                <Image source={Menuicon3} style={{height: 25, width: 25}} tintColor="#7EA8CA" resizeMode="contain" />
                <Image source={Menuicon4} style={{height: 25, width: 25}} tintColor="#7EA8CA" resizeMode="contain" />
            </View>
            
            
            
            <ScrollView>
                
                
                <View style={[styles.row, {paddingHorizontal: 15, paddingTop: 6}]}>
                    <View />
                    {/*<Image source={user} style={{height: 60, width: 60}} resizeMode="contain" />*/}
                    <Image source={logo} style={{height: 60, width: 100, marginRight: -45}} resizeMode="contain" />
                    <View style={[styles.row, {width: 45}]}>
                        {/*<View style={{width:45, height: 45, backgroundColor:"#00A0BC", borderRadius: 31, alignItems:"center", justifyContent:"center"}}>
                            <Image source={icon1} style={{height: 20, width: 20}} resizeMode="contain" />
                        </View>*/}
                        <View style={{width:40, height: 40, borderColor:"#00A0BC", borderWidth: 1, borderRadius: 31, alignItems:"center", justifyContent:"center"}}>
                            <Image source={icon2} style={{height: 20, width: 20}} tintColor="#00A0BC" resizeMode="contain" />
                        </View>
                    </View>
                </View>


                <View style={{padding:20, width:"100%"}}>
                    
                    <View style={{height:10}} />

                    <View style={[styles.row, {backgroundColor: "#C7F0F9", borderRadius:30, padding:20}]}>
                        <View style={{flex:1}}>
                            <Text style={[styles.H3, {color: "#00A0BC"}]}>Queremos asignarte al personal ideal</Text>
                            <Text style={[styles.pLight, {color: "#6F757A"}]}>Nuestro equipo de profesionales es  maravilloso, sin embargo nos guartaría enviarte a alguien con quien te sientas cómodo y te brinde un servicio más cercano.</Text>
                            <Text style={{color: "#00A0BC", paddingTop:7, fontSize:16, fontFamily:"pp_regular", fontWeight:"bold"}}>Déjanos conocerte</Text>
                        </View>
                    </View>

                    <View style={{height:30}} />

                    <View style={{width:"100%", position:"relative", height:200}}>
                        <Image source={articulo1} style={{width: "100%", backgroundColor:"lime", borderRadius: 20, position:"absolute"}} resizeMode="cover" />
                        <View style={{width:"100%", position:"absolute", zIndex: 2}}>
                            <Image source={articulo1} style={{width: "100%", opacity:0}} resizeMode="cover" />
                            <View style={{marginTop:-150, padding:20}}>
                                <Text style={[styles.H1, {color: "white"}]}>El aseo en casa es Vital</Text>
                                <Text style={[styles.p, {color: "white"}]}>Sabías que hacer el aseo en casa ayuda a mejorar las relaciones de pareja?...</Text>
                                <Text style={[styles.p, {color: "white", paddingTop:10}]}>Leer Más</Text>
                            </View>
                        </View>
                    </View>

                    <View style={{height:30}} />

                    <TareasCard navigation={props.navigation} callback={item => {}} tareas={[{id: "1", date:moment().valueOf(), text:"Buscar a los niños a la ecuela"},{id: "2", date:moment().valueOf(), text:"Buscar a los niños a la ecuela"},{id: "3",date:moment().valueOf(), text:"Buscar a los niños a la ecuela"}]}/>
                    <View style={{height:30}} />
                    <TareasCard navigation={props.navigation} callback={item => {}} tareas={[{id: "1", date:moment().valueOf(), text:"Buscar a los niños a la ecuela"},{id: "2", date:moment().valueOf(), text:"Buscar a los niños a la ecuela"},{id: "3",date:moment().valueOf(), text:"Buscar a los niños a la ecuela"}]}/>

                    <View style={{height:90}} />

                </View>
            </ScrollView>

        </SafeAreaView >
    )
}

export default Home

const _styles = StyleSheet.create({

    button: {
        position: "absolute", 
        width: 70, 
        height: 70, 
        bottom:15,
        justifyContent:"center", 
        alignItems:"center",
        left:"50%", 
        marginLeft: -5, 
        backgroundColor:"#00A0BC", 
        borderRadius:35, 
        borderWidth: 5, 
        borderColor: "#fff"
    }
})