import React, { useState, useEffect, useRef, useContext } from 'react'
import { View, SafeAreaView, Text, StatusBar, ScrollView, TextInput } from 'react-native'
import { styles, COLORS } from '../global/styles'
import {Button} from '../components'



const CrearCuenta = (props) => {

    return (
        <SafeAreaView style={styles.main}>
            <StatusBar backgroundColor={COLORS.backgroundColor} barStyle="dark-content" />

            <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled" style={{padding:20, width:"100%"}}>
    
                <Text style={[styles.H1, {color: "#00A0BC", paddingLeft: 15}]}>Inicio de sesión</Text>
                <View style={{height:65}}></View>
                
    

                <Text style={styles.labelInputs}>Número de documento</Text>
                <View style={styles.inputs}>
                    <TextInput
                        placeholder=""
                        keyboardType="numeric"
                        style={styles.textInputs}
                        onChangeText={text => {}}
                        value={""}
                    />
                </View>
                <View style={{height:15}}></View>


                <Text style={styles.labelInputs}>Contraseña</Text>
                <View style={styles.inputs}>
                    <TextInput
                        placeholder=""
                        keyboardType="default"
                        style={styles.textInputs}
                        onChangeText={text => {}}
                        value={""}
                        secureTextEntry={true}
                    />
                </View>
                <View style={{height:15}}></View>
                <Text style={{color: "#6F757A", fontFamily:"pp_medium", paddingLeft:8, textDecorationLine:"underline"}}>¿Olvido su contraseña?</Text>


                <View style={{height:40}}></View>
                <Button
                    onPress={() => {}}
                    loading={false}
                    title="Ingresar" 
                    textColor="white" 
                />

                <View style={{height:30}}></View>
                <Button
                    style={{backgroundColor:"transparent"}}
                    onPress={() => {}}
                    loading={false}
                    title="Regístrate" 
                    textColor="#00A0BC" 
                />



            </ScrollView>
        </SafeAreaView>
    )

}

export default CrearCuenta