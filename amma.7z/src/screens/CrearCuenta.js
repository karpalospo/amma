import React, { useState, useEffect, useRef, useContext } from 'react'
import { View, SafeAreaView, Text, StatusBar, ScrollView, TextInput } from 'react-native'
import { styles, COLORS } from '../global/styles'
import {Button} from '../components'
import BouncyCheckbox from "react-native-bouncy-checkbox";


const CrearCuenta = (props) => {

    const [checked, setChecked] = useState(false)
    const [tipoDocumento, setTipoDocumento] = useState("")
    const [numDocumento, setNumDocumento] = useState("")
    const [email, setEmail] = useState("")
    const [celular, setCelular] = useState("")
    const [password, setPassword] = useState("")

    return (
        <SafeAreaView style={styles.main}>
            <StatusBar backgroundColor={COLORS.backgroundColor} barStyle="dark-content" />

            <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled" style={{padding:20, width:"100%"}}>
    
                <Text style={[styles.H1, {color: "#00A0BC", paddingLeft: 15}]}>Crear una cuenta</Text>
                <View style={{height:15}}></View>
                
                <Text style={styles.labelInputs}>Tipo de documento</Text>
                <View style={styles.inputs}>
                    <TextInput
                        placeholder=""
                        keyboardType="default"
                        style={styles.textInputs}
                        onChangeText={text => setTipoDocumento(text)}
                        value={tipoDocumento}
                    />
                </View>
                <View style={{height:15}}></View>

                <Text style={styles.labelInputs}>Número de documento</Text>
                <View style={styles.inputs}>
                    <TextInput
                        placeholder=""
                        keyboardType="numeric"
                        style={styles.textInputs}
                        onChangeText={text => setNumDocumento(text)}
                        value={numDocumento}
                    />
                </View>
                <View style={{height:15}}></View>

                <Text style={styles.labelInputs}>Email</Text>
                <View style={styles.inputs}>
                    <TextInput
                        placeholder=""
                        keyboardType="email-address"
                        style={styles.textInputs}
                        onChangeText={text => setEmail(text)}
                        value={email}
                    />
                </View>
                <View style={{height:15}}></View>

                <Text style={styles.labelInputs}>Número de Celular</Text>
                <View style={styles.inputs}>
                    <TextInput
                        placeholder=""
                        keyboardType="numeric"
                        style={styles.textInputs}
                        onChangeText={text => setCelular(text)}
                        value={celular}
                    />
                </View>
                <View style={{height:15}}></View>

                <Text style={styles.labelInputs}>Contraseña</Text>
                <View style={styles.inputs}>
                    <TextInput
                        placeholder=""
                        keyboardType="default"
                        style={styles.textInputs}
                        onChangeText={text => setPassword(text)}
                        value={password}
                        secureTextEntry={true}
                    />
                </View>
                <View style={{height:15}}></View>

                <BouncyCheckbox
                    size={25}
                    fillColor="#00A0BC"
                    unfillColor="#FFFFFF"
                    text="Al acceder, aceptas las politicas de privacidad, terminos del servicio y tratamiento de datos personales."
                    iconStyle={{ borderRadius: 4, borderColor: "#00A0BC" }}
                    textStyle={{ fontFamily: "pp_light", fontSize: 13, textDecorationLine: "none" }}
                    onPress={isChecked => setChecked(isChecked)}
                />

                <View style={{height:30}}></View>
                <Button
                    onPress={() => {}}
                    loading={false}
                    title="Crear Una Cuenta" 
                    textColor="white" 
                />



            </ScrollView>
        </SafeAreaView>
    )

}

export default CrearCuenta