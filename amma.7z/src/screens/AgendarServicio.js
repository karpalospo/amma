import React, { useState, useEffect, useRef, useContext } from 'react'
import { View, SafeAreaView, Text, StatusBar, ScrollView, StyleSheet, Image } from 'react-native'
import { styles, COLORS } from '../global/styles'
import {Header} from '../components'
import { TouchableOpacity } from 'react-native-gesture-handler'


const hogar = require("../../assets/hogar.png")
const empresa = require("../../assets/empresa.png")

const Agendar = ({navigation}) => {

    return (
        <SafeAreaView style={styles.main}>
            <Header label="Agendar" navigation={navigation} />
            <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled" style={{padding:20, width:"100%"}}>
    
                <Text style={{paddingVertical:35, color:"#00A0BC", fontSize: 17, paddingLeft:20}}>Elige el tipo de servicio que necesitas</Text>

                <TouchableOpacity onPress={() => navigation.navigate("AgendarHogar")} style={[styles.rowLeft, {paddingLeft:30}]}>
                    <Image source={hogar} style={{height: 100, width: 100}} resizeMode="contain" />
                    <Text style={{color: "#00A0BC", fontSize:17, paddingLeft: 11, fontFamily:"pp_bold"}}>Hogar</Text>
                </TouchableOpacity>
                <View style={{height:40}} />
                <TouchableOpacity style={[styles.rowLeft, {paddingLeft:30}]}>
                    <Image source={empresa} style={{height: 100, width: 100}} resizeMode="contain" />
                    <Text style={{color: "#E9ADD7", fontSize:17, paddingLeft: 11, fontFamily:"pp_bold"}}>Empresa</Text>
                </TouchableOpacity>

            </ScrollView>
        </SafeAreaView>
    )

}

export default Agendar