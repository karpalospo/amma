import React, { useState, useEffect, useRef, useContext } from 'react'
import { View, SafeAreaView, Text, StatusBar, Image, StyleSheet } from 'react-native'
import { styles, COLORS } from '../global/styles'
import AppIntroSlider from 'react-native-app-intro-slider';


const limpieza1 = require("../../assets/limp1.png")
const limpieza2 = require("../../assets/limp2.png")
const limpieza3 = require("../../assets/limp3.png")


const slides = [
    {
      key: 'one',
      title: 'Title 1',
      text: 'Servicio Hogar',
      image: limpieza1,
      desc: "Lorem ipsum es el texto que se usa habitualmente en diseño gráfico"
    },
    {
      key: 'two',
      title: 'Title 2',
      text: 'Servicio Empresa',
      image: limpieza2,
      desc: "Lorem ipsum es el texto que se usa habitualmente en diseño gráfico"
    },
    {
      key: 'three',
      title: 'Title 3',
      text: 'Otro',
      image: limpieza3,
      desc: "Lorem ipsum es el texto que se usa habitualmente en diseño gráfico"
    }
  ];

const Onboarding = (props) => {

    const _renderItem = ({ item }) => {
        return (
            <View style={_styles.slide}>
                <Image source={item.image} style={{width:"80%", height:250}} resizeMode="contain" />
                <View style={{height:40}} />
                <Text style={[styles.H1, {color: "#00A0BC", fontSize:28}]}>{item.text}</Text>
                <Text style={[styles.p, {color: "#6F757A", fontSize:14, paddingHorizontal: 40}]}>{item.desc}</Text>
            </View>
        )
    };


    return (
        <SafeAreaView style={styles.main}>
            <StatusBar backgroundColor={COLORS.backgroundColor} barStyle="dark-content" />
            <AppIntroSlider
                data={slides}
                renderItem={_renderItem}
                showNextButton={false}
                showDoneButton={false}
                activeDotStyle={{backgroundColor: "#00A0BC"}}
                dotStyle={{backgroundColor: "#D8F6FE"}}
            />
        </SafeAreaView>
    )
}

export default Onboarding

const _styles = StyleSheet.create({
    buttonCircle: {
        width: 40,
        height: 40,
        backgroundColor: 'rgba(0, 0, 0, .2)',
        borderRadius: 20,
        justifyContent: 'center',
        alignItems: 'center',
    },
    slide: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
      },
      image: {
        width: 320,
        height: 320,
        marginVertical: 32,
      },
      text: {
        color: 'rgba(255, 255, 255, 0.8)',
        textAlign: 'center',
      },
      title: {
        fontSize: 22,
        color: 'white',
        textAlign: 'center',
      },
});