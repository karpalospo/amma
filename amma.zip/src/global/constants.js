
    export const values = {

        tipoSangre: [
            {id: "0", label: "O+", value: "O+"},
            {id: "1", label: "A-", value: "A-"},
            {id: "2", label: "A+", value: "A+"},
            {id: "3", label: "B-", value: "B-"},
            {id: "4", label: "B+", value: "B+"},
            {id: "5", label: "AB-", value: "AB-"},
            {id: "6", label: "AB+", value: "AB+"}
        ],
        departamentos: [{id: "0", label: "Atlántico", value: "1"}],
        municipios: [{id: "1", label: "Baranoa", value: "1"}, {id: "2", label: "Puerto Colombia", value: "2"}, ] 
    }